<?php if(! defined('ABSPATH')){ return; }
/**
 * Template layout for project category entries
 * @package  Kallyas
 * @author   Team Hogash
 */
get_template_part( 'archive', 'portfolio' ); ?>