var baseParam = require( './base' );
module.exports = baseParam.extend({
	template: require('../../html/textarea.html'),
});