<?php

$revSlidersConfig = array(
	array(
		'name' => 'fitness_slider',
		'file' => 'fitness_slider.zip'
	),
	array(
		'name' => '3d',
		'file' => '3d.zip'
	),
);
