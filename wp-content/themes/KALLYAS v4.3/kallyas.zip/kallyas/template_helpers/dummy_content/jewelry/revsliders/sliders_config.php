<?php

$revSlidersConfig = array(
	array(
		'name' => 'homepage-slider',
		'file' => 'homepage-slider.zip'
	),
	array(
		'name' => 'blog-slider',
		'file' => 'blog-slider.zip'
	),
	array(
		'name' => 'alternative-slider',
		'file' => 'alternative-slider.zip'
	),
);
