<?php

$revSlidersConfig = array(
	array(
		'name' => '3d',
		'file' => '3d.zip'
	),
	array(
		'name' => 'blog-slider',
		'file' => 'blog-slider.zip'
	),
	array(
		'name' => 'homepage-slider',
		'file' => 'homepage-slider.zip'
	),
);
