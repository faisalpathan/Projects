<?php

$revSlidersConfig = array(
	array(
		'file' => 'creative-slider-v4.zip'
	),
	array(
		'file' => 'shop-slider-part-2.zip'
	),
	array(
		'file' => 'shop-slider-v4.zip'
	),
);
